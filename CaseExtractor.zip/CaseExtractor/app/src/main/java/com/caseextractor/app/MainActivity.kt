package com.caseextractor.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var btnSelectPdf: MaterialButton
    private lateinit var btnExtract: MaterialButton
    private lateinit var btnCopyAll: MaterialButton
    private lateinit var tvFileName: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvResultTitle: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var spinnerColumn: Spinner
    private lateinit var recyclerResults: RecyclerView

    private var pickedUri: Uri? = null
    private var pickedName: String = ""
    private var lastRows: List<Row> = emptyList()
    private var lastHeaderRowIdx: Int = -1

    private val adapter = ResultsAdapter(mutableListOf())

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            pickedUri = uri
            pickedName = getDisplayName(uri)
            tvFileName.text = pickedName
            btnExtract.isEnabled = true
            btnExtract.alpha = 1f
        }
    }

    private fun getDisplayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "selected_file"
        try {
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
            }
        } catch (_: Exception) { }
        return name
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnSelectPdf = findViewById(R.id.btnSelectPdf)
        btnExtract = findViewById(R.id.btnExtract)
        btnCopyAll = findViewById(R.id.btnCopyAll)
        tvFileName = findViewById(R.id.tvFileName)
        tvStatus = findViewById(R.id.tvStatus)
        tvResultTitle = findViewById(R.id.tvResultTitle)
        progressBar = findViewById(R.id.progressBar)
        spinnerColumn = findViewById(R.id.spinnerColumn)
        recyclerResults = findViewById(R.id.recyclerResults)

        recyclerResults.layoutManager = LinearLayoutManager(this)
        recyclerResults.adapter = adapter

        btnSelectPdf.setOnClickListener {
            pdfPicker.launch(arrayOf(
                "application/pdf",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.ms-excel",
                "image/jpeg",
                "image/png"
            ))
        }

        btnExtract.setOnClickListener {
            runExtraction()
        }

        btnCopyAll.setOnClickListener {
            copyAllToClipboard()
        }
    }

    private fun runExtraction() {
        val uri = pickedUri ?: return
        btnExtract.isEnabled = false
        progressBar.visibility = View.VISIBLE
        progressBar.progress = 0
        tvStatus.text = "Reading PDF..."
        spinnerColumn.visibility = View.GONE
        adapter.update(emptyList())

        lifecycleScope.launch {
            try {
                val name = pickedName.lowercase()
                val rows = withContext(Dispatchers.IO) {
                    when {
                        name.endsWith(".xlsx") || name.endsWith(".xls") -> {
                            runOnUiThread { tvStatus.text = "Reading Excel file..." }
                            FileProcessor.readExcel(this@MainActivity, uri)
                        }
                        name.endsWith(".docx") -> {
                            runOnUiThread { tvStatus.text = "Reading Word file..." }
                            FileProcessor.readWord(this@MainActivity, uri)
                        }
                        name.endsWith(".jpg") || name.endsWith(".jpeg") || name.endsWith(".png") -> {
                            runOnUiThread { tvStatus.text = "Running OCR on image..." }
                            PdfOcrEngine.processImage(this@MainActivity, uri)
                        }
                        else -> {
                            val file = PdfOcrEngine.copyToCache(this@MainActivity, uri)
                            PdfOcrEngine.processPdf(this@MainActivity, file) { done, total ->
                                runOnUiThread {
                                    progressBar.progress = ((done.toFloat() / total) * 100).toInt()
                                    tvStatus.text = "OCR: page $done / $total complete..."
                                }
                            }
                        }
                    }
                }
                lastRows = rows

                val (headerRowIdx, candidates) = PdfOcrEngine.headerCandidates(rows)
                lastHeaderRowIdx = headerRowIdx

                if (candidates.size > 1) {
                    spinnerColumn.visibility = View.VISIBLE
                    val spinnerAdapter = ArrayAdapter(
                        this@MainActivity,
                        android.R.layout.simple_spinner_dropdown_item,
                        candidates
                    )
                    spinnerColumn.adapter = spinnerAdapter
                    spinnerColumn.onItemSelectedListener =
                        object : android.widget.AdapterView.OnItemSelectedListener {
                            override fun onItemSelected(
                                parent: android.widget.AdapterView<*>?, view: View?, pos: Int, id: Long
                            ) {
                                val values = PdfOcrEngine.extractColumnAt(lastRows, lastHeaderRowIdx, pos)
                                tvResultTitle.text = candidates[pos]
                                adapter.update(values)
                            }
                            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                        }
                }

                val (headerText, values) = PdfOcrEngine.extractCaseColumn(rows)
                tvResultTitle.text = headerText
                adapter.update(values)

                progressBar.visibility = View.GONE
                tvStatus.text = "Done — ${values.size} values found."
            } catch (e: Exception) {
                progressBar.visibility = View.GONE
                tvStatus.text = "Error: ${e.message}"
                Toast.makeText(this@MainActivity, "Extraction failed: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                btnExtract.isEnabled = true
            }
        }
    }

    private fun copyAllToClipboard() {
        val items = (0 until recyclerResults.adapter!!.itemCount)
        val sb = StringBuilder()
        // Re-derive current visible values from the engine output rather than the view holders
        val (_, values) = if (spinnerColumn.visibility == View.VISIBLE && spinnerColumn.selectedItemPosition >= 0) {
            tvResultTitle.text.toString() to PdfOcrEngine.extractColumnAt(lastRows, lastHeaderRowIdx, spinnerColumn.selectedItemPosition)
        } else {
            PdfOcrEngine.extractCaseColumn(lastRows)
        }
        values.forEach { sb.append(it).append("\n") }

        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("case_numbers", sb.toString().trim()))
        Toast.makeText(this, "Copied (${values.size} values)", Toast.LENGTH_SHORT).show()
    }
}
